package BikePoint.service;

import java.util.ArrayList;
import java.util.HashMap;

public interface IBikePoint {
    ArrayList<HashMap> obtenerAllBikePoints();
    
}
