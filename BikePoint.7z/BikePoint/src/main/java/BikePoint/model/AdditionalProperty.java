package BikePoint.model;

import java.util.Date;

public class AdditionalProperty{
    public String $type;
    public String category;
    public String key;
    public String sourceSystemKey;       //NbBikes -NbDocks -NbEmptyDocks
    public String value;
    public Date modified;
} 
