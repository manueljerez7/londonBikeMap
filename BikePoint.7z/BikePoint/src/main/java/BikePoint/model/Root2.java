package BikePoint.model;

import java.util.ArrayList;

public class Root2{
    public String $type;
    public String id;     //
    public String url;
    public String commonName;    //
    public String placeType;
    public ArrayList<AdditionalProperty> additionalProperties;
    public ArrayList<Object> children;
    public ArrayList<Object> childrenUrls;
    public double lat;    //
    public double lon;    //
}

